import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import SanPham from './components/SanPham/SanPham';
import CtSanPham from './components/Chitiet/CtSanPham';
import AddSanPham from './components/AddSanPham/AddSanPham';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="SanPham" component={SanPham} options={ {title:'Sản phẩm'}}/>
        <Stack.Screen name="CtSanPham" component={CtSanPham} options={ {title:'Chi tiết'}}/>
        <Stack.Screen name="AddSanPham" component={AddSanPham} options={ {title:'Thêm Sản phẩm'}}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
