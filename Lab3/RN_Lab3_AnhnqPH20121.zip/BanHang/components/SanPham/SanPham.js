import { FlatList, Text, View, Image, TouchableOpacity, Button, Alert } from 'react-native';

import styles from './Style'

export default function SanPham({navigation}) {
  let inputData = [
    {
      id: 1,
      proName: 'Samsung Galaxy S22 Bora Purple',
      proPrice: 12490000,
      proCategory: 'Điện thoại',
      content: 'Bật nét kiêu kỳ, sẵn sàng trendy với phiên bản Samsung Galaxy S22 màu tím (Bora Purple), bạn sẽ trở nên thật thời thượng, ấn tượng và cá tính. Đồng hành đó là những công nghệ tốt nhất của Samsung từ hiệu năng Snapdragon 8 Gen 1, màn hình cao cấp cho đến hệ thống camera chuyên nghiệp.',
      proImg: 'https://images.fpt.shop/unsafe/fit-in/214x214/filters:quality(90):fill(white)/fptshop.com.vn/Uploads/Originals/2022/11/1/638028878218412584_samsung-galaxy-s22-bora-purple-dd-docquyen-bh.jpg',
    },
    {
      id: 2,
      proName: 'Laptop Asus TUF Gaming',
      proPrice: 16690000,
      proCategory: 'Laptop',
      content: 'Asus TUF Gaming F15 FX506LHB-HN188W là chiếc laptop gaming giá rẻ với thiết kế tuyệt đẹp, phong cách chuẩn game thủ và cấu hình mạnh mẽ cho cả học tập, công việc cũng như chơi game. Bên cạnh đó là độ bền chuẩn quân đội đã làm nên tên tuổi của dòng TUF.',
      proImg: 'https://images.fpt.shop/unsafe/fit-in/214x214/filters:quality(90):fill(white)/fptshop.com.vn/Uploads/Originals/2022/1/26/637787904727727554_asus-tuf-gaming-fx506lh-den-2022-dd.jpg',
    },
    {
      id: 3,
      proName: 'MacBook Air 13" 2020',
      proPrice: 21999000,
      proCategory: 'Laptop',
      content: 'Chiếc MacBook Air có hiệu năng đột phá nhất từ trước đến nay đã xuất hiện. Bộ vi xử lý Apple M1 hoàn toàn mới đưa sức mạnh của MacBook Air M1 13 inch 2020 vượt xa khỏi mong đợi người dùng, có thể chạy được những tác vụ nặng và thời lượng pin đáng kinh ngạc.',
      proImg: 'https://images.fpt.shop/unsafe/fit-in/214x214/filters:quality(90):fill(white)/fptshop.com.vn/Uploads/Originals/2020/11/12/637407970062806725_mba-2020-gold-dd.png',
    },
    {
      id: 4,
      proName: 'Samsung Galaxy Tab A7 Lite',
      proPrice: 3490000,
      proCategory: 'Máy tính bảng',
      content: 'Với thiết kế siêu mỏng, tính năng giải trí hấp dẫn và hiệu năng vượt trội, Samsung Galaxy Tab A7 Lite sẽ là người bạn đồng hành đầy phong cách dành cho cuộc sống của bạn. Tha hồ học hỏi, khám phá, kết nối trong niềm cảm hứng của công nghệ.',
      proImg: 'https://images.fpt.shop/unsafe/fit-in/214x214/filters:quality(90):fill(white)/fptshop.com.vn/Uploads/Originals/2021/5/27/637577199955105403_ss-tab-a7-lite-bac-dd.jpg',
    },
    {
      id: 5,
      proName: 'Apple Watch SE 2 GPS 40mm',
      proPrice: 6490000,
      proCategory: 'Smartwatch',
      content: 'Có quá nhiều lý do để bạn yêu Apple Watch SE 2022. Thiết kế năng động, cảm biến mạnh mẽ mang đến đầy đủ các thông tin về sức khỏe, hỗ trợ tập luyện hiệu quả, hiệu suất vượt trội và luôn luôn kết nối, Apple Watch SE 2 (2022) là chiếc đồng hồ thông minh giá tốt phù hợp cho tất cả mọi người.',
      proImg: 'https://images.fpt.shop/unsafe/fit-in/214x214/filters:quality(90):fill(white)/fptshop.com.vn/Uploads/Originals/2022/9/12/637985938871192764_apple-watch-se-2-40mm-gps-den-dd.jpg',
    },
  ];
  return (
    <><FlatList
      contentContainerStyle={styles.container}
      keyExtractor={(item, index) => index.toString()}
      data={inputData}
      renderItem={({ item }) => (
        <TouchableOpacity onPress={() => navigation.navigate('CtSanPham',
          {
            proName: item.proName,
            proPrice: item.proPrice,
            proCategory: item.proCategory,
            content: item.content,
            proImg: item.proImg
          })}>
          <View style={styles.items}>
            <View style={styles.imageBox}>
              <Image
                style={styles.image}
                source={{ uri: item.proImg }} />
            </View>
            <View style={styles.textBox}>
              <Text style={styles.proName}>{item.proName}</Text>
              <Text style={styles.proPrice}>Giá bán: {item.proPrice} VNĐ</Text>
            </View>
          </View>
        </TouchableOpacity>
      )} />
      <View style = {styles.addBtnBox}>
        <TouchableOpacity style = { styles.addBtnBgr} onPress={() => navigation.navigate('AddSanPham')}>
            <Text style = { styles.addBtn }>Thêm sản phẩm</Text>
          </TouchableOpacity>
      </View>
    </>
  );
}
