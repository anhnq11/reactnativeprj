import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container:{
        width: '100%',
        height: '100%',
        // justifyContent: 'center',
        alignItems: 'center',
        paddingTop: 10,
    },
    items:{
        width: 350,
        height: 80,
        // justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 10,
        borderRadius: 10,
        flexDirection: 'row',
        borderWidth: 1,
        borderColor:'black',
        overflow: 'hidden'
    },
    imageBox:{  
        width: 80,
        height: 80,
        marginHorizontal: 10,
        justifyContent: 'center',
        alignItems: 'center',
    },
    image:{
        width: '100%',
        height: '80%',
    },
    textBox:{
        width: '70%',
        overflow: 'hidden'
    },
    proName:{
        color: 'black',
        fontSize: 20,
        // marginBottom: 10,
    },
    proPrice:{
        color: '#1DA1F2',
        fontSize: 20,
        fontWeight: 'bold'
    },
    addBtnBox:{
        width: '100%',
        alignItems: 'center'
    },
    addBtnBgr:{
        backgroundColor: '#1DA1F2',
        borderRadius: 10,
        marginBottom: 10,
        paddingVertical: 5
    },
    addBtn:{
        width: 200,
        textAlign: 'center',
        color: 'white',
        fontSize: 20,
        fontWeight: 'bold'
    }
})