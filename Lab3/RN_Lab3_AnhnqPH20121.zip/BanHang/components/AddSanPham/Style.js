import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container:{
        width: '100%',
        height: '100%',
        alignItems: 'center',
    },
    input:{
        width: '90%',
        height: 40,
        marginHorizontal: 12,
        marginTop: 10,
        borderWidth: 1,
        padding: 10,
        borderRadius: 10,
    },
    uploadImgBgr:{
        height: 80,
        width: 100,
        marginTop: 10,
        borderWidth: 1,
        padding: 10,
        borderRadius: 10,
    },
    uploadImgText:{
        fontSize: 50,
        borderWidth: 1,
        borderColor: 'black'
    },
    btnBox:{
        width: '90%',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    btn:{
        width: 150,
        backgroundColor: '#1DA1F2',
        padding: 5,
        alignItems: 'center',
        borderRadius: 10,
        marginTop: 10,
        marginHorizontal: 5
    },
    btnText:{
        color: 'white',
        fontSize: 18
    }
})