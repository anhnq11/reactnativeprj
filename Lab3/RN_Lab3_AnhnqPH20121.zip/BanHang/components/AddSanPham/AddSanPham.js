import { View, Text, TextInput, TouchableOpacity } from 'react-native'
import React from 'react'
import { useState } from 'react'
import styles from './Style'

const AddSanPham = () => {

  const [Img, setImg] = useState('');
  const [proName, setproName] = useState('');
  const [proPrice, setproPrice] = useState(0);
  const [proCat, setproCat] = useState('');
  const [content, setcontent] = useState('');

  const reset = () => {
    console.log('Reset Click!!!');
    setImg('');
    setproName('');
    setproPrice('');
    setproCat('');
    setcontent('');
  }

  const changeImg = (data) => {
    setImg(data);
  }
  const changName = (data) => {
    setproName(data);
  }
  const changPrice = (data) => {
    setproPrice(data);
  }
  const changeCat = (data) => {
    setproCat(data);
  }
  const changeContent = (data) => {
    setcontent(data);
  }

  return (
    <View style = { styles.container}>
      <TextInput
        style = { styles.input }
        placeholder = 'Nhập ảnh sản phẩm'
        onChangeText={changeImg}
        value = {Img}
      />
      <TextInput
        style = { styles.input }
        placeholder = 'Nhập tên sản phẩm'
        onChangeText={changName}
        value = {proName}
      />
      <TextInput
        style = { styles.input }
        placeholder = 'Nhập giá sản phẩm'
        keyboardType='numeric'
        onChangeText={changPrice}
        value = {proPrice}
      />
      <TextInput
        style = { styles.input }
        placeholder = 'Nhập thể loại sản phẩm'
        onChangeText={changeCat}
        value = {proCat}
      />
      <TextInput
        style = { styles.input }
        placeholder = 'Nhập mô tả sản phẩm'
        onChangeText={changeContent}
        value = {content}
      />
      <View style = {styles.btnBox}>
        <TouchableOpacity style = {styles.btn} onPress = {() => reset()}>
          <Text style = { styles.btnText }>Reset</Text>
        </TouchableOpacity>
        <TouchableOpacity style = {styles.btn}>
          <Text style = { styles.btnText }>Thêm sản phẩm</Text>
        </TouchableOpacity>
      </View>
    </View>
  )
}

export default AddSanPham