import { View, Text, Image } from 'react-native'
import React from 'react'
import styles from './Style'

const CtSanPham = ({route}) => {
  return (
    <View style = {styles.container}>
      <View style = {styles.imageBox}>
        <Image style = {styles.image} source = {{uri: route.params.proImg}}/>
      </View>
      <Text style = {styles.proName}>{route.params.proName}</Text>
      <Text style = {styles.proPrice}>Giá bán: {route.params.proPrice} VNĐ</Text>
      <View style = {styles.contentBox}>
        <Text style = {styles.content}>Mô tả: {route.params.content}</Text>
      </View>
      <Text style = {styles.proCategory}>Thể loại: {route.params.proCategory}</Text>
    </View>
  )
}

export default CtSanPham