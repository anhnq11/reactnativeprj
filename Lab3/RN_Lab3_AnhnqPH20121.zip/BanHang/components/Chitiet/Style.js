import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container:{
        width: '100%',
        height: '100%',
        alignItems: 'center'
    },
    imageBox:{
        width: '90%',
        height: 350,
        backgroundColor: 'red',
        borderRadius: 10,
        marginTop: 10,
    },
    image:{
        width: '100%',
        height: '100%'
    },
    proName:{
        color: '#1DA1F2',
        fontSize: 22,
        fontWeight: 'bold',
    },
    proPrice:{
        color: 'red',
        fontSize: 20,
        fontWeight: 'bold'
    },
    contentBox:{
        width: '90%',
    },
    content:{
        color: 'black',
        fontSize: 18,
    },
    proCategory:{
        color: 'black',
        fontSize: 20,
        fontWeight: 'bold'
    },
})