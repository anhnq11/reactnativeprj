import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container:{
        width: '100%',
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    content:{
        borderTopWidth: 2,
        borderLeftWidth: 2,
        borderTopColor: 'black',
        borderLeftColor: 'black',
    },
    row:{
        flexDirection: 'row',
        borderBottomWidth: 2,
        borderBottomColor: 'black',
    },
    cell:{
        width: 60,
        height: 50,
        backgroundColor: '#0572E5',
        borderRightWidth: 2,
        borderRightColor: 'black'
    },
    celll:{
        width: 60,
        height: 50,
        borderRightWidth: 2,
        borderRightColor: 'black'
    },
    author:{
        fontSize: 18,
        color: '#0572E5',
        marginTop: 10
    }
})