import { StatusBar } from 'expo-status-bar';
import { Text, View } from 'react-native';
import styles from "./Style";

export default function App() {
  return (
    <View style={styles.container}>
      <View style = {styles.content}>
        <View style = {styles.row}>
          <View style = {styles.cell}></View>
          <View style = {styles.celll}></View>
          <View style = {styles.cell}></View>
          <View style = {styles.celll}></View>
        </View>
        <View style = {styles.row}>
          <View style = {styles.celll}></View>
          <View style = {styles.cell}></View>
          <View style = {styles.celll}></View>
          <View style = {styles.cell}></View>
        </View>
        <View style = {styles.row}>
          <View style = {styles.cell}></View>
          <View style = {styles.celll}></View>
          <View style = {styles.cell}></View>
          <View style = {styles.celll}></View>
        </View>
        <View style = {styles.row}>
          <View style = {styles.celll}></View>
          <View style = {styles.cell}></View>
          <View style = {styles.celll}></View>
          <View style = {styles.cell}></View>
        </View>
      </View>
      <Text style = {styles.author}>Nguyễn Quốc Anh - PH20121</Text>
    </View>
  );
}

